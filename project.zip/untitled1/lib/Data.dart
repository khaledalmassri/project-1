List<Map<String, String>> students = [
  {'id': '1', 'name': 'nawfal', 'gender': 'Male'},
  {'id': '2', 'name': 'Jane', 'gender': 'Female'},
  {'id': '3', 'name': 'saif', 'gender': 'Male'},

];

List<String> events = ['Football','Tennis','BascketBall'];

List<Map<String, String>> students1 = [
  {'id': '1', 'name': 'nawfal', 'gender': 'Male', 'sport': 'Football'},
  {'id': '2', 'name': 'Jane', 'gender': 'Female', 'sport': 'Basketball'},
  {'id': '3', 'name': 'saif', 'gender': 'Male', 'sport': 'Football'},
  {'id': '4', 'name': 'ali', 'gender': 'Male', 'sport': 'Basketball'},
  {'id': '5', 'name': 'bilal', 'gender': 'Male', 'sport': 'running'},
  {'id': '6', 'name': 'Nadim', 'gender': 'Male', 'sport': 'Tennis'},
];
